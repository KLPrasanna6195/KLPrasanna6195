from django.db import models

# Create your models here.
class BMI(models.Model):
    gender = models.CharField(max_length=500, null=False, blank=False)
    height_in_cms = models.FloatField()
    weight_in_kg = models.FloatField()

    def __str__(self):
        return self.gender

    class Meta:
        db_table = "bmi_table"