from django.apps import AppConfig


class BmiConfig(AppConfig):
    name = 'bmi'
