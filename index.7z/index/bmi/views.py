from django.shortcuts import render
import json
from rest_framework.response import Response
from django.http import HttpResponse
from rest_framework import status
from bmi.models import BMI
from rest_framework.decorators import api_view


# Create your views here.

@api_view(['get'])
def get_bmi(request):
    height = request.GET.get('height','None')
    height=float(height)
    weight = request.GET.get('weight','None')
    bmi = float(weight)/float(height*height)
    if float(bmi) <= 24.9:
        return Response({'Your BMI is', bmi, 'you are underweight'},status=status.HTTP_200_OK)

    elif 25.0 < float(bmi) < 29.9:
        return Response({'Your BMI is', bmi, 'you are normal'},status=status.HTTP_200_OK)

    elif 30 < float(bmi) < 34.9:
        return Response({'your BMI is', bmi, ' you are overweight'},status=status.HTTP_200_OK)

    elif 35 < float(bmi) < 39.9:
        return Response({'your BMI is', bmi, ' you are moderately obese'},status=status.HTTP_200_OK)

    elif float(bmi) > 40:
        return Response({'Your BMI is', bmi, ' you are severely obese'},status=status.HTTP_200_OK)
